import React, { useState } from 'react';
import { Moon, Sun, Mail, Phone, Linkedin, Github, Send } from 'lucide-react';

function App() {
  const [isDarkMode, setIsDarkMode] = useState(true);

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
  };

  const skills = [
    { name: 'HTML/CSS', icon: '🌐' },
    { name: 'JavaScript', icon: '⚡' },
    { name: 'React.js', icon: '⚛️' },
    { name: 'Flutter & Dart', icon: '📱' },
    { name: 'React Native', icon: '📲' }
  ];

  return (
    <div className={`min-h-screen ${isDarkMode ? 'bg-gray-900 text-white' : 'bg-white text-gray-900'} transition-colors duration-300`}>
      {/* Header with Dark Mode Toggle */}
      <header className="fixed w-full top-0 z-50 p-4 flex justify-between items-center">
        <h1 className="text-2xl font-bold">NAHOM ZEMED</h1>
        <button
          onClick={toggleDarkMode}
          className="p-2 rounded-full hover:bg-gray-700 transition-colors"
        >
          {isDarkMode ? <Sun className="w-6 h-6" /> : <Moon className="w-6 h-6" />}
        </button>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 pt-20">
        {/* Hero Section */}
        <section className="flex flex-col items-center py-12">
          <div className="relative">
            <div className="w-48 h-48 rounded-full overflow-hidden border-4 border-blue-600 animate-pulse">
              <img
                src="/nahom.jpg"
                alt="Nahom Zemed"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
          <h2 className="text-3xl font-bold mt-6">Nahom Zemed</h2>
          <p className="text-xl text-blue-400 mt-2">Frontend Developer | JavaScript</p>
        </section>

        {/* Navigation Buttons */}
        <nav className="flex flex-wrap justify-center gap-4 my-8">
          {['Home', 'About Me', 'Download CV', 'Contact Me'].map((item) => (
            <button
              key={item}
              className="px-6 py-2 bg-orange-200 text-gray-900 rounded-lg hover:bg-blue-600 hover:text-white transition-colors"
            >
              {item}
            </button>
          ))}
        </nav>

        {/* Introduction */}
        <section className="max-w-2xl mx-auto text-center my-12 p-6 rounded-lg bg-opacity-10 bg-blue-500">
          <p className="text-lg leading-relaxed">
            As a Computer Science Student and a passionate developer, I would like to announce that I'm ready for Remote, Contractual and Freelancing Jobs which might be related with my role and also I'm eager to work for Entry-Level Workshops and Workshops.
          </p>
        </section>

        {/* Skills Section */}
        <section className="my-12">
          <h3 className="text-2xl font-bold text-center mb-6">Skills</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 max-w-2xl mx-auto">
            {skills.map((skill) => (
              <div key={skill.name} className="flex items-center p-4 rounded-lg bg-blue-500 bg-opacity-10">
                <span className="text-2xl mr-2">{skill.icon}</span>
                <span>{skill.name}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Contact Information */}
        <section className="my-12">
          <div className="max-w-md mx-auto space-y-4">
            <div className="flex items-center gap-4">
              <Mail className="w-6 h-6 text-red-500" />
              <a href="mailto:nahizem967@gmail.com" className="hover:text-blue-400">nahizem967@gmail.com</a>
            </div>
            <div className="flex items-center gap-4">
              <Phone className="w-6 h-6 text-blue-400" />
              <div>
                <p>+251974094401</p>
                <p>+251940096516</p>
              </div>
            </div>
          </div>
        </section>

        {/* Social Links */}
        <section className="flex justify-center gap-6 my-12">
          <a
            href="https://www.linkedin.com/in/nahom-zemed"
            target="_blank"
            rel="noopener noreferrer"
            className="p-3 rounded-full bg-blue-600 hover:bg-blue-700 transition-colors"
          >
            <Linkedin className="w-6 h-6" />
          </a>
          <a
            href="https://t.me/NAHOMIEL"
            target="_blank"
            rel="noopener noreferrer"
            className="p-3 rounded-full bg-blue-400 hover:bg-blue-500 transition-colors"
          >
            <Send className="w-6 h-6" />
          </a>
          <a
            href="mailto:nahizem967@gmail.com"
            className="p-3 rounded-full bg-red-500 hover:bg-red-600 transition-colors"
          >
            <Mail className="w-6 h-6" />
          </a>
          <a
            href="https://github.com/NahomZemed/nahomzemed.git"
            target="_blank"
            rel="noopener noreferrer"
            className="p-3 rounded-full bg-gray-700 hover:bg-gray-800 transition-colors"
          >
            <Github className="w-6 h-6" />
          </a>
        </section>
      </main>
    </div>
  );
}

export default App;